module FREDI {
	exports com.fredi.graphique;
	exports com.fredi;

	requires java.desktop;
	requires java.sql;
}