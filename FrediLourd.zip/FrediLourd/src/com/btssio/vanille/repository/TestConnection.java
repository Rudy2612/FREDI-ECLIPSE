package com.btssio.vanille.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TestConnection {
	public static void main(String... args) {
		Connection conn = null;
		try {

			// MySQL driver MySQL Connector
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/vanille?useSSL=false&useLegacyDatetimeCode=false", "Rudy",
					"Azerty31!");
			conn.setAutoCommit(false);

			// on ouvre la connexion et en plus de créer un insert, on l'execute
			Statement stmt2 = conn.createStatement();
			String requeteSQL = "INSERT INTO produit(PDT_id, description, prix, image, idCategorie) VALUES ('BO08','Fraise géante X 50 guimauve en boite 1kg',17.81,'images/bonbons/bonbon7.png','BON')";
			stmt2.executeUpdate(requeteSQL);
			// on ferme la connexion puis on en ré-ouvre une seoncde
			stmt2.close();

			// on créer une troisieme connexion, une requête et on
			// l'execute avant de refermer la co
			Statement stmt3 = conn.createStatement();
			requeteSQL = "INSERT INTO produit(PDT_id, description, prix, image, idCategorie) VALUES ('BI01','Petits sablés de Noël',4.2,'images/biscuits/biscuit1.png','BIS')";
			stmt3.executeUpdate(requeteSQL);
			stmt3.close();

			Statement stmt4 = conn.createStatement();
			// on créer une autre reqête insert on l'execute et on referme la connexion
			requeteSQL = "Insert into categorie(CAT_id,libelle) values ('bis','Biscuits')";
			stmt4.executeUpdate(requeteSQL);
			stmt4.close();

			conn.commit();

			// Oracle Driver officiel OJDBC Thin
			// conn =
			// DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:vanille","root","");
			// Postgres Driver officiel
			// conn =
			// DriverManager.getConnection("jdbc:postgresql://localhost:5432/vanille","root","");
			System.out.println("success");

			if (conn != null) {
				conn.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {

				// Création de la connexion
//				Statement stmt1 = conn.createStatement();
				// On rédige la requête SQL
//				String requeteSQL = "select * from categorie";
				// On créer une variable pour récuperer les resultats
//				ResultSet res;
				// on execture la requête et on stocke les résultats
//				res = stmt1.executeQuery(requeteSQL);
				// Comme en php avec le fetch, on parcours les résultats
//				while (res.next()) {
//					System.out.print(res.getString("CAT_id") + " ");
//					System.out.println(res.getString(2));
//				}
				// on ferme la connexion
//				stmt1.close();

				// on créer la connexion
//				Statement stmt2 = conn.createStatement();
				// on écrit la requête dans une string
//				String requeteSQL = "Insert into categorie(CAT_id,libelle) values ('bis','Biscuits')";
				// on execute la requête et on stocks le nombre de ligne qui ont été ajouté
//				int nbRows = stmt2.executeUpdate(requeteSQL);
				// on print le nombre de ligne et on close la connexion à la base de données
//				System.out.println(nbRows);
//				stmt2.close();

				// on créer la requête
//				String requeteSQL = "update categorie set libelle = ? where CAT_id = ?";
				// On prépare la requête (comme en php)
//				PreparedStatement prep1 = conn.prepareStatement(requeteSQL);
				// On assigne aux différents "?" des valeurs
//				prep1.setString(1, "Biscuits secs");
//				prep1.setString(2, "Bis");
				// On execute la requête et ferme la connexion
//				prep1.executeUpdate();
//				prep1.close();

				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
