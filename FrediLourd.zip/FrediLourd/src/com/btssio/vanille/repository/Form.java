package com.btssio.vanille.repository;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Form extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblKilomtres;
	private JTextField textField_1;
	private JLabel lblNewLabel_2;
	private JTextField textField_2;
	private JLabel lblNewLabel_3;
	private JTextField textField_3;
	private JLabel lblNewLabel_4;
	private JTextField textField_4;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_5;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Form frame = new Form();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Form() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 150, 430, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		textField = new JTextField();
		textField.setBounds(24, 96, 316, 30);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel = new JLabel("Adresse mail demandeur");
		lblNewLabel.setBounds(24, 80, 149, 14);
		contentPane.add(lblNewLabel);

		// button research
		JButton btnNewButton = new JButton("\uD83D\uDD0E");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Connection conn = null;
				// on se connecte à la base de données
				try {
					conn = DriverManager.getConnection(
							"jdbc:mysql://localhost:3306/vanille?useSSL=false&useLegacyDatetimeCode=false", "Rudy",
							"Azerty31!");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnNewButton.setBounds(342, 95, 51, 30);
		contentPane.add(btnNewButton);

		lblKilomtres = new JLabel("Kilom\u00E8tres");
		lblKilomtres.setBounds(25, 206, 149, 14);
		contentPane.add(lblKilomtres);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(25, 222, 368, 30);
		contentPane.add(textField_1);

		lblNewLabel_2 = new JLabel("P\u00E9age");
		lblNewLabel_2.setBounds(25, 263, 149, 14);
		contentPane.add(lblNewLabel_2);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(25, 279, 368, 30);
		contentPane.add(textField_2);

		lblNewLabel_3 = new JLabel("Repas");
		lblNewLabel_3.setBounds(25, 320, 149, 14);
		contentPane.add(lblNewLabel_3);

		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(25, 336, 368, 30);
		contentPane.add(textField_3);

		lblNewLabel_4 = new JLabel("H\u00E9bergement");
		lblNewLabel_4.setBounds(25, 377, 149, 14);
		contentPane.add(lblNewLabel_4);

		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(25, 393, 368, 30);
		contentPane.add(textField_4);

		lblNewLabel_1 = new JLabel("Trajet concern\u00E9 :");
		lblNewLabel_1.setBounds(24, 157, 369, 14);
		contentPane.add(lblNewLabel_1);

		lblNewLabel_5 = new JLabel("Date du frais :");
		lblNewLabel_5.setBounds(24, 181, 369, 14);
		contentPane.add(lblNewLabel_5);

		btnNewButton_1 = new JButton("Valider");
		btnNewButton_1.setBounds(231, 458, 89, 23);
		contentPane.add(btnNewButton_1);

		btnNewButton_2 = new JButton("Refuser");
		btnNewButton_2.setBounds(98, 458, 89, 23);
		contentPane.add(btnNewButton_2);

		JLabel lblNewLabel_6 = new JLabel("2500\u20AC");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(158, 25, 96, 26);
		contentPane.add(lblNewLabel_6);

		JLabel lblNewLabel_6_1 = new JLabel("Somme total");
		lblNewLabel_6_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1.setBounds(158, 11, 96, 14);
		contentPane.add(lblNewLabel_6_1);
	}
}
