package com.btssio.vanille;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	// on créer une sessionFactory (1 par base de données)
	private static final SessionFactory sessionFactory = buildSessionFactory();

	private static SessionFactory buildSessionFactory() {
		try {
			// Create the SessionFactory from hibernate.cfg.xml
			// (il créer réèllement la session factory via le fichier que on a mis)
			return new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			// si la connexion ne s'établie pas
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static SessionFactory getSessionFactory() {

		return sessionFactory;
	}
}